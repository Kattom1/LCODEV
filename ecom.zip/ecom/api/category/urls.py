from rest_framework import routers
from django.urls import path,include

from . import views

router = routers.DefaultRouter()
router.register(r'', views.CategoryViewSet) #path is here is empty coz it is taken care of in api.url


urlpatterns = [
    
    path('',include(router.urls))
] 