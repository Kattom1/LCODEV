from django.db import migrations
from api.user.models import CustomUser

class Migration(migrations.Migration):
    def seed_data(apps, schema_editor):
        user = CustomUser(name="mini",
                        email="mini123mariam@gmail.com",
                        is_staff=True,
                        is_superuser=True,
                        phone="9916942490",
                        gender="female"
                        )
        
        user.set_password("12345")
        user.save()


    dependencies = [

    ]

    operations = [
        migrations.RunPython(seed_data), #please dont change the comma, coz it will ensure that there will be only one data in the lsit
    ]