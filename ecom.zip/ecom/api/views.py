from django.http import JsonResponse

# Create your views here.



#declaring the function home that is used in the urls.py in the api app Ketto di patti
def home(request):
    return JsonResponse({'info':'Django React Course','name':"mini"})